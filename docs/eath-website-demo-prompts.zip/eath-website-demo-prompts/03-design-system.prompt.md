# 03 — Design tokens, typography and minimal-shadow system

## Read first

Master, approved audit/work log, `references/asset-manifest.md`. Implement shared visual primitives, not complete pages.

## 1. Scope

Use `.eath-demo` as a preview theme boundary or an equivalent audited wrapper. Do not change admin globals or unapproved live website styling. Reuse existing SCSS organization; keep Vite admin entries and required plugins. Inspect Bootstrap/framework dependencies instead of assuming installation. Keep required existing JS until references prove it unused.

## 2. Font contract

Display/editorial: `Newsreader, Georgia, serif`. Body/UI: `Inter, system-ui, sans-serif`. Font weights: 400, 500, 600 only where actually used. Existing licensed/local font files first; do not block implementation on external font services. Use swap/fallback behavior and do not preload every weight.

| Token | Mobile / desktop | Font | Line height |
| --- | --- | --- | --- |
| --type-display | 40 / 64px | Newsreader 500 | 1.08 |
| --type-h1 | 34 / 48px | Newsreader 500 | 1.10 |
| --type-h2 | 30 / 40px | Newsreader 500 | 1.15 |
| --type-h3 | 24 / 32px | Newsreader 500 | 1.20 |
| --type-h4 | 21 / 24px | Inter 500 | 1.25 |
| --type-card-title | 20 / 24px | Inter 500 | 1.30 |
| --type-body-large | 17 / 18px | Inter 400 | 1.65 |
| --type-body | 16px | Inter 400 | 1.65 |
| --type-small | 14px | Inter 400 | 1.55 |
| --type-caption | 13px | Inter 400 | 1.45 |
| --type-micro | 12px | Inter 500 | 1.40 |

Use rem units; never shrink the root font size to fit content. Use semantic heading levels independently of visual classes. One H1 per page. Body copy should not exceed about 65–75 characters per line. Micro is for nonessential metadata, not important form instructions.

Suggested fluid tokens (375–1280px design range; use the caps, not new arbitrary per-section sizes):

```scss
.eath-demo {
  --font-display: 'Newsreader', Georgia, serif;
  --font-body: 'Inter', system-ui, sans-serif;
  --type-display: clamp(2.5rem, 1.878rem + 2.652vw, 4rem);
  --type-h1: clamp(2.125rem, 1.762rem + 1.547vw, 3rem);
  --type-h2: clamp(1.875rem, 1.616rem + 1.105vw, 2.5rem);
  --type-h3: clamp(1.5rem, 1.293rem + 0.884vw, 2rem);
}
```

## 3. Color tokens

```scss
.eath-demo {
  --color-primary: #183b32;
  --color-primary-hover: #102d26;
  --color-primary-soft: #e7efeb;
  --color-secondary: #285447;
  --color-accent: #c8653a;
  --color-accent-action: #a64b28;
  --color-background: #fcfcf9;
  --color-background-warm: #f5f2ea;
  --color-surface: #ffffff;
  --color-text: #1d2421;
  --color-text-secondary: #5e6863;
  --color-text-muted: #7d8581;
  --color-border: #e3e5e1;
  --color-control-border: #727b75;
  --color-error: #a83f36;
  --color-focus: #245fa8;
  --color-on-primary: #ffffff;
}
```

Important correction to the older pack: muted gray and the original rust are not automatic small-text/button pairings. Use secondary text for readable small copy; reserve muted for non-text/decorative uses unless the actual combination passes contrast. Use darker accent-action with white for accent buttons. Light borders separate decorative surfaces only; use stronger control boundaries where needed. Verify all actual pairings; do not assume a named token is accessible.

## 4. Spacing and geometry

Scale in pixels: 4, 8, 12, 16, 20, 24, 32, 40, 48, 56, 64, 72, 80, 96, 120. Express reusable rem tokens. No arbitrary negative margins to hide alignment errors.

- Main content max: 1280px including consistent inner gutters.
- Wide editorial imagery: 1440px max when deliberately used.
- Reading column: max 800px and comfortable character measure.
- Gutters: mobile 20px, tablet 24px, desktop 32–40px.
- Normal sections: mobile 56px, tablet 80px, desktop 96px block padding.
- Major editorial section: up to 120px desktop. Compact related sections: 64–72px desktop.
- Content determines height. Do not clip headings or fix all cards to a text-height that truncates essential content.

Radii: controls 8px; cards 12px; large photos 16px; editorial image max 20px; pills999px only for chips/badges. Button min-height48px default, 52px prominent, 44px compact interactive. Icon sizes16/20/24px; choose one installed icon system or small reusable inline SVGs.

## 5. No-shadow policy

Normal cards, filter panels, planner sections, sticky booking panels and standard header use **box-shadow: none** within their owned component styles. Depth comes from whitespace, border, surface and image composition. Do not add filter drop-shadow, text glow or hover elevation.

Only functional overlay dropdown/dialog/drawer may use one shared token: `0 8px 24px rgb(29 36 33 / 0.10)`, if a border is insufficient. Document each exception. Focus uses `outline: 2px solid` with offset; on dark backgrounds use a contrasting light outline. Do not globally disable shadow-based focus from unrelated components.

## 6. Components and states

Build theme-level patterns for buttons (primary/outline/ghost/text/icon), links, badges, persistent labels, inputs/selects/textareas, checkboxes/radios, errors, section headings, dividers, facts/metadata and banners.

Each interactive control has hover, active, focus-visible, disabled and busy states. Link vs button semantics follow actual navigation vs action. No nested links/buttons in clickable cards. Card hover can adjust border or text color; no hover-only content.

## 7. Responsive and motion

Test320/375/640/768/1024/1280/1440px. Usual grids3→2→1; editorial splits stack; drawer replaces desktop menu; comparison scroll stays inside its region. Respect content order and min-width:0 in grids. Reduced-motion disables nonessential transitions; ordinary transitions150–200ms. No content-hidden reveal animations.

## Acceptance

Create a local demo style review view if useful, gated with preview. Inspect long titles, multiple-line buttons, validation, 200% zoom and dark focus. Check no shadow outside allowed overlays, no font/icon duplicates and no admin regressions. Compile the existing Vite pipeline and report actual results.
